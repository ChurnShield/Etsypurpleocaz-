FINE-LINE BOTANICAL TATTOO BUNDLE
by PurpleOcaz

Thank you for your purchase!

WHAT'S INCLUDED:
- 120 unique fine-line botanical tattoo designs
- Each design in 5 formats: SVG, PNG, DXF, PDF, EPS

FORMATS:
- SVG: Scalable vector, works with Cricut/Silhouette and design software
- PNG: 4096x4096 transparent background, high resolution
- DXF: Compatible with AutoCAD and cutting machines
- PDF: Vector format, perfect for printing at any size
- EPS: Professional vector format for design software

CATEGORIES:
- Birth-Flowers: 12 designs
- Botanical-Stems: 12 designs
- Bouquets: 15 designs
- Decorative: 14 designs
- Mini: 25 designs
- Roses: 12 designs
- Wildflowers: 18 designs
- Wreaths-and-Frames: 12 designs

HOW TO USE:
1. Choose your design from the categorized folders
2. Pick the format that works for your project
3. Import into your design software or cutting machine

TIPS:
- SVG is best for cutting machines (Cricut, Silhouette)
- PNG is best for digital use, social media, and web
- PDF is best for printing
- DXF is best for CAD software and laser cutters
- EPS is best for professional design software (Illustrator)

NEED HELP?
Email: purpleocaz@gmail.com

Enjoy your designs!
- The PurpleOcaz Team